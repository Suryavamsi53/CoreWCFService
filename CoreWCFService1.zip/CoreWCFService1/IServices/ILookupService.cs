﻿

using System.Collections.Generic;
using System.ServiceModel;
using System.Threading.Tasks;
using System.Diagnostics.CodeAnalysis;
using System.Runtime.Serialization;
using CoreWCF;
using CoreWCFService1.Models;


namespace CoreWCFService1.IServices
{


    [CoreWCF.ServiceContract]
    public interface ILookupService
    {
        [CoreWCF.OperationContract]
        Task<IEnumerable<Lookup>> GetAllLookups();

        [CoreWCF.OperationContract]
        Task<Lookup> GetLookupById(int id);

        [CoreWCF.OperationContract]
        Task AddLookup(Lookup lookup);

        [CoreWCF.OperationContract]
        Task UpdateLookup(Lookup lookup);

        [CoreWCF.OperationContract]
        Task DeleteLookup(int id);
    }
}
